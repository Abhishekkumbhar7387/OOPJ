package in.cdac.kh;

import java.util.Scanner;

public class VehicleTesting {


	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
      Vehicle obj=new Vehicle();
      
        int choice=0;
        do {
        	System.out.println(" =================================");
            System.out.println("   Enter Choice : ");
            System.out.println("0. To Exit :");
            System.out.println("1. Enter vehicle type (car, van, bus, or truck) : ");
            System.out.println("2. Enter number of axles : ");
            System.out.println("3. Enter distance travelled : ");
            System.out.println("4. Calculate toll fee  : ");
            System.out.println("5. Generate bill  : ");
          choice =sc.nextInt();	
           
           switch(choice)
           {
           case 1:
        	   String name=sc.next();
        	   obj.setVehicleType(name); 
        	   break;
           case 2:
        	   int no=sc.nextInt();
        	   obj.setNoOfAxles(no);
        	   break;
           case 3:
        	   System.out.println("Enter user's account no :  ");
        	  double dist=sc.nextDouble();
               obj.setDistanceTravelled(dist);
        	   break;
           case 4:
        	   obj.calculateTollFee();
        	   
        	   break;
           case 5:
        	  
               System.out.println("Generated Bill : "+    obj.generateBill() + " $ ");
        	   break;
           default :
        	   System.out.println("Please Enter choice from 0-5 ");
        		   
           
        	   
        	   
           }
           
           
        }while(choice!=0);
        
 	   System.out.println("=======================");
        
        
	}

}
