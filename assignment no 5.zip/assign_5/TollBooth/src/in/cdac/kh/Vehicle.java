package in.cdac.kh;

public class Vehicle {
	private String vehicleType;
	private int noOfAxles;
	private double distanceTravelled;
	private double tollFee;
	private double totalAmountDue;
	
	public void calculateTollFee()
	{
		if(vehicleType=="car" || vehicleType=="bus" || vehicleType=="van" )
		{
			tollFee=0.25*distanceTravelled*noOfAxles;
			System.out.println("TollFee : "+tollFee);
		}
		else
		{
			tollFee=0.50*distanceTravelled*noOfAxles;
			System.out.println("TollFee : "+tollFee);
		}
	}
	
	public double generateBill()
	{
		return 2*tollFee;
	}

	public Vehicle(String vehicleType, int noOfAxles, double distanceTravelled, double tollFee, double totalAmountDue) {
		super();
		this.vehicleType = vehicleType;
		this.noOfAxles = noOfAxles;
		this.distanceTravelled = distanceTravelled;
		this.tollFee = tollFee;
		this.totalAmountDue = totalAmountDue;
	}

	public Vehicle() {
		super();
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public int getNoOfAxles() {
		return noOfAxles;
	}

	public void setNoOfAxles(int noOfAxles) {
		this.noOfAxles = noOfAxles;
	}

	public double getDistanceTravelled() {
		return distanceTravelled;
	}

	public void setDistanceTravelled(double distanceTravelled) {
		this.distanceTravelled = distanceTravelled;
	}

	public double getTollFee() {
		return tollFee;
	}

	public void setTollFee(double tollFee) {
		this.tollFee = tollFee;
	}

	public double getTotalAmountDue() {
		return totalAmountDue;
	}

	public void setTotalAmountDue(double totalAmountDue) {
		this.totalAmountDue = totalAmountDue;
	}
	
	
	
	
	
	
	

}
