package in.cdac.kh;

import java.time.LocalDate;
import java.util.Calendar;

public class Date {
	private int date;
	private int month;
	private int year;
	
	
	public boolean isValid()
	{
		boolean flag=false;
		if(year >1800 && year <9999)
		{
			flag=true;
		}
		
		return flag;
	}
	
	public String getDayOfWeek()
	{
		LocalDate d=LocalDate.of(year,month,date);
		 return d.getDayOfWeek().toString();
	}
	
	public boolean isLeapYear()
	{
		LocalDate d=LocalDate.of(year,month,date);
		return d.isLeapYear();
	}
	
	public void getNextDate()
	{
		
		LocalDate d=LocalDate.of(year,month,date);
		d=d.plusDays(1);
	
	System.out.println(d.toString());
	}
	
	public void getPreciousDate()
	{
		LocalDate d=LocalDate.of(year,month,date);
	
		d=d.minusDays(1);
		System.out.println(d.toString());
	}
	
	public int getDate() {
		return date;
	}
	
	public void setDate(int date) {
		this.date = date;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	
}
