package in.cdac.kh;



import java.time.LocalDate;
import java.util.Scanner;

public class DateClass{
	
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a date :");
		int da=sc.nextInt();
		System.out.println("enter a month :");
		int month=sc.nextInt();
		System.out.println("enter a year:");
		int year=sc.nextInt();
		Date date=new Date();
		
		date.setDate(da);
		date.setMonth(month);
		date.setYear(year);
		
		System.out.println(date.isValid());
	
		System.out.println(date.getDayOfWeek());
		System.out.println(date.isLeapYear());
		date.getNextDate();
		date.getPreciousDate();
		
	}
		
		//System.out.println(date.isValid()); 
		
		// true System.out.println(date.getDayOfWeek()); 
		// 6 (Saturday) System.out.println(date.isLeapYear()); // false 
		 
		//Date nextDay = date.getNextDay(); 
		//System.out.println(nextDay); // 01-01-2023 
		 
		//Date previousDay = date.getPreviousDay(); 
		//System.out.println(previousDay); // 30-12-2022 
		
		
		
		
	

}
