package in.cdac.kh;

import java.util.Scanner;

public class CreditScoreTesting {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length of credit history : ");
		int l=sc.nextInt();
		System.out.println("Enter Available credit : ");
		double d=sc.nextDouble();
		
		System.out.println("Enter has good payment history or not (true , false) : ");
		boolean b=sc.nextBoolean();
		
		CreditScore credit=new CreditScore(l,d,b);
		System.out.println("-------------");
		System.out.println("Credit Score : "+credit.calculateCreditScore());
		
	}

}
