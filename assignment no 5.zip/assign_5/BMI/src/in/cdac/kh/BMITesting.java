package in.cdac.kh;

import java.util.Scanner;

public class BMITesting {
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Height : ");
		double height=sc.nextDouble();
		System.out.println("Enter Your Weight : ");
		double weight=sc.nextDouble();
		
		BMICalculator bmi=new BMICalculator();
		bmi.setHeight(height);
		bmi.setWeight(weight);
	double res=bmi.calculateBMI();

		System.out.println("--------------");
		System.out.printf("BMI is : %.4f  ",bmi.calculateBMI());
		
		
	}

}
