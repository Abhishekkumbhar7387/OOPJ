import java.util.Scanner;

public class BillTesting {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Customer Name : ");
	String name=sc.nextLine();
	System.out.println("Enter ConsumedUnits : ");
	double units=sc.nextDouble();
	
	ElectricityBill bill=new ElectricityBill(name,units);
	 
		System.out.println("------------------------");
	System.out.println("Electricity Bill : "+ bill.calculateBillAmount());
}
}
