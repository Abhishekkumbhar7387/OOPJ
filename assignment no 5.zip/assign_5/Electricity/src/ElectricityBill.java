
public class ElectricityBill {

	private String customerName;
	private double unitsConsumed;
	private double billAmount;
	public ElectricityBill(String customerName, double unitsConsumed) {
		super();
		this.customerName = customerName;
		this.unitsConsumed = unitsConsumed;
		
	}
	public ElectricityBill() {
		super();
	}
	
	
	public double calculateBillAmount()
	{
		if(unitsConsumed <= 100 )
		{
			billAmount=unitsConsumed*5;
		}
		else if(unitsConsumed <= 200)
		{
			billAmount=5*100+7*(unitsConsumed-100);
		}
		else
		{
		
			
			double r=(unitsConsumed-100); //125 //225
			//System.out.println("----"+(unitsConsumed-r)+" "+(unitsConsumed-200));
			billAmount=5*100+7*(unitsConsumed-r)+10*(unitsConsumed-200);
		}
		
		return billAmount;
	}
	
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(double unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}
	public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	
	
}
