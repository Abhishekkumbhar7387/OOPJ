package in.cdac.kh;

public class DateFormat {
	private int date;
	private int month;
	private int year;
	
	
	
	
	public DateFormat() {
	
	}
	
	public int getDate()
	{
		return this.date;
	}
	
	public int getMonth()
	{
		return this.month;
	}
	
	public int getYear()
	{
		return this.year;
	}
	
	public void setDate(int date)
	{
		this.date=date;
	}
	
	public void setMonth(int month)
	{
		this.month=month;
	}
	
	public void setYear(int year)
	{
		this.year=year;
	}
	
}
