package in.cdac.kh;

import java.util.Date;
import java.util.Scanner;

public class DateWithDateClass {

	public static void main(String[] args)
	{
	
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Date: ");
		int d=sc.nextInt();
		System.out.println("Enter Month: ");
		int m=sc.nextInt();
		System.out.println("Enter Year: ");
		int y=sc.nextInt();
		
		Date date=new Date();
		date.setDate(d);
		date.setMonth(m);
		date.setYear(y);
		
		System.out.println("------------");
		System.out.println("dd/mm/yyyy : "+date.getDate()+"/"+(date.getMonth()+1)+"/"+(date.getYear()+1900));
		System.out.println("mm/dd/yyyy : "+(date.getMonth()+1)+"/"+date.getDate()+"/"+(date.getYear()+1900));
		System.out.println("yyyy/mm/dd : "+(date.getYear()+1900)+"/"+(date.getMonth()+1)+"/"+date.getDate());
	}
}
