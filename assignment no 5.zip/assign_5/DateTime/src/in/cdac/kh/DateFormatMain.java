package in.cdac.kh;

import java.util.Scanner;

public class DateFormatMain {
	public static void main(String[] args)
	{
		DateFormat date=new DateFormat();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Date: ");
		int d=sc.nextInt();
		System.out.println("Enter Month: ");
		int m=sc.nextInt();
		System.out.println("Enter Year: ");
		int y=sc.nextInt();
		
	
		date.setDate(d);
		date.setMonth(m);
		date.setYear(y);
		
		System.out.println("------------");
		System.out.println("dd/mm/yyyy : "+date.getDate()+"/"+date.getMonth()+"/"+date.getYear());
		System.out.println("mm/dd/yyyy : "+date.getMonth()+"/"+date.getDate()+"/"+date.getYear());
		System.out.println("yyyy/mm/dd : "+date.getYear()+"/"+date.getMonth()+"/"+date.getDate());
	}

}
