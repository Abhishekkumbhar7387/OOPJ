package in.cdac.kh;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UserDateTime {
	public static void main(String[] args)
	{
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Date: ");
		int d=sc.nextInt();
		System.out.println("Enter Month: ");
		int m=sc.nextInt();
		System.out.println("Enter Year: ");
		int y=sc.nextInt();
		
		
		System.out.println("Enter Sec: ");
		int s=sc.nextInt();
		System.out.println("Enter Min: ");
		int min=sc.nextInt();
		System.out.println("Enter Hrs: ");
		int h=sc.nextInt();
		
		Date date=new Date();
		
		
		
		date.setDate(d);
		date.setMonth(h);
		date.setYear(y);
		date.setSeconds(s);
		date.setMinutes(m);
		date.setHours(h);
		
		 SimpleDateFormat form=new  SimpleDateFormat("dd/mm/yy hh:mm:ss aa");
		String str=form.format(date);
		
		System.out.println("------------");
		System.out.println("dd/mm/yyyy hh:mm:ss "+"dd/mm/yyyy : "+date.getDate()+"/"+date.getMonth()+"/"+date.getYear()+" "+
				date.getHours()+":"+date.getMinutes()+":"+date.getSeconds());
		System.out.println("hh:mm:ss a : "+str);
		System.out.println("yyyy/mm/dd hh:mm "+date.getYear()+"/"+date.getMonth()+"/"+date.getDate()+" "+date.getHours()+
				":"+date.getMinutes());
		
		
		
		
	}
}
