package in.cdac.kh;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Scanner;

public class UserTime {
	public static void main(String[] args)
	{
	
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Sec: ");
		int s=sc.nextInt();
		System.out.println("Enter Min: ");
		int m=sc.nextInt();
		System.out.println("Enter Hrs: ");
		int h=sc.nextInt();
		
		Date date=new Date();
		date.setSeconds(s);
		date.setMinutes(m);
		date.setHours(h);
		
		 SimpleDateFormat form=new  SimpleDateFormat("hh:mm:ss aa");
		String str=form.format(date);
		
		System.out.println("------------");
		System.out.println("hh:mm:ss : "+date.getHours()+":"+date.getMinutes()+":"+date.getSeconds());
		System.out.println("hh:mm:ss a : "+str);
		System.out.println("hh:mm : "+date.getHours()+":"+date.getMinutes()+":");
		
		
		
		
	}
}
