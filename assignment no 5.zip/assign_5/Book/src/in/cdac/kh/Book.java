package in.cdac.kh;

public class Book {
	private String title;
	private String author;
	private String publisher;
	private String isbn;
	private int year;
	private double price;
	private int quantity;
	
	
	
	
	public Book() {
		super();
	}
	public Book(String title, String author, String publisher, String isbn, int year, double price, int quantity) {
		super();
		this.title = title;
		this.author = author;
		this.publisher = publisher;
		this.isbn = isbn;
		this.year = year;
		this.price = price;
		this.quantity = quantity;
	}
	
	
	
	public void increaseQuanity(int quantity)
	{
		this.quantity=this.quantity+quantity;
	}
	
	public void decreaseQuanity(int quantity)
	{
		this.quantity=this.quantity-quantity;
	}
	
	public double getInventoryValue()
	{
		
		return this.price * this.quantity;
	}
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
