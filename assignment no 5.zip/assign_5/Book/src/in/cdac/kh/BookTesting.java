package in.cdac.kh;

import java.util.Scanner;

public class BookTesting {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Book Title :");
		String title=sc.nextLine();
		System.out.println("Enter Book Author :");
		String author=sc.nextLine();
		System.out.println("Enter Book Publisher :");
		String publisher=sc.nextLine();
		System.out.println("Enter Book ISBN No :");
		String isbn=sc.nextLine();
		System.out.println("Enter Book Year :");
		int year=sc.nextInt();
		System.out.println("Enter Book Price :");
		double price=sc.nextDouble();
		System.out.println("Enter Book Quantity :");
		int quantity=sc.nextInt();
		
		Book book=new Book();
		book.setTitle(title);
		book.setAuthor(author);
		book.setPublisher(publisher);
		book.setIsbn(isbn);
		book.setYear(year);
		book.setPrice(price);
		book.setQuantity(quantity);
		
		System.out.println("Enter Book Quantity to Increse :");
		int quanAdd=sc.nextInt();
		
		book.increaseQuanity(quanAdd);
		
		
		System.out.println("Enter Book Quantity to Decrese :");
		int quanDec=sc.nextInt();
		book.decreaseQuanity(quanDec);
		String s=" ";
		System.out.println("-----------------");
		System.out.println("Book Title : "+book.getTitle());
		System.out.println("Book Author : "+book.getAuthor());
		System.out.println("Book Publisher : "+book.getPublisher());
		System.out.println("Book ISBN No : "+book.getIsbn());
		System.out.println("Book Year : "+book.getYear());
		System.out.println("Book Price  "+book.getPrice());
		System.out.println("Book Quantity : "+book.getQuantity());
		System.out.println("Final Book Prize Will Be : "+book.getInventoryValue());
		System.out.println("-----------------");
		
		
	}

}
