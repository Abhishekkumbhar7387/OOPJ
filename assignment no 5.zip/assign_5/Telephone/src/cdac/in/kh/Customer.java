package cdac.in.kh;

public class Customer {

	private String customerName;
	private long phoneNo;
	private int noOfCallsMade;
	private int durationOfCall;
	public Customer(String customerName, long phoneNo, int noOfCallsMade, int durationOfCall) {
		super();
		this.customerName = customerName;
		this.phoneNo = phoneNo;
		this.noOfCallsMade = noOfCallsMade;
		this.durationOfCall = durationOfCall;
	}
	
	public double calculateBill()
	{
		double price=0;
		double per=10/(30*24*60);
		if(noOfCallsMade <=100 )
		{
			if(durationOfCall >=60)
			price=100*(0.5)*10/(30*24*60);
			else
				price=100*0.5*10/(30*24*60);
		}
		else if(noOfCallsMade >100 )
		{
			if(durationOfCall >=60)
			price=(noOfCallsMade-100)*0.25*1+100*0.5*10/(30*24*60);
			else
				price=(noOfCallsMade-100)*0.25*60+100*0.5*10/(30*24*60);
		}
		
		return (price);
			
		}
		
		
	
	
	
	public Customer() {
		super();
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getNoOfCallsMade() {
		return noOfCallsMade;
	}
	public void setNoOfCallsMade(int noOfCallsMade) {
		this.noOfCallsMade = noOfCallsMade;
	}
	public int getDurationOfCall() {
		return durationOfCall;
	}
	public void setDurationOfCall(int durationOfCall) {
		this.durationOfCall = durationOfCall;
	}
	
	
	
}
