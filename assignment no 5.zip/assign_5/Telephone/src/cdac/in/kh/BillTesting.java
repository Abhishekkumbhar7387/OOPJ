package cdac.in.kh;

import java.util.Scanner;

public class BillTesting {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Name : ");
		String name=sc.nextLine();
		System.out.println("Enter Phone No : ");
		long no=sc.nextLong();
		System.out.println("Enter No of calls made : ");
		int call=sc.nextInt();
		System.out.println("Enter Duration in minutes : ");
		int dur=sc.nextInt();
		
		Customer bill=new Customer(name,no,call,dur);
		 
			System.out.println("------------------------");
		System.out.printf("Electricity Bill : %.5f  $",bill.calculateBill() );
	}
}
